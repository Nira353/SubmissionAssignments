using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
[System.Serializable]

public class Wave
{
    public string name;
    public int noOfEnemies;
    public float spawnInterval;
}

public class EnemyWaveController : MonoBehaviour
{
    public enum SpawnState { waitPlayer, spawning, counting };

    public Wave[] waves;
    public Transform[] spawnPoints;

    public int nextWave = 0;
    public float waveInterval = 5f;
    public float waveCountdown;

    public Enemy enemy;
    public GameController gameController;

    private SpawnState state = SpawnState.counting;

    private void Awake()
    {
        waveCountdown = waveInterval;
    }

    private void Update()
    {
        if(state == SpawnState.waitPlayer)
        {
            //check if any enemy is alive
            if(GameObject.FindGameObjectWithTag("Enemy") == null)
            {
                WaveCompleted();
            }
            else
            {
                return;
            }
        }

        if(waveCountdown <= 0)
        {
            if(state != SpawnState.spawning)
            {
                StartCoroutine( SpawnWave( waves[nextWave] ) );
            }
        }
        else
        {
            waveCountdown -= Time.deltaTime;
        }
    }

    IEnumerator SpawnWave(Wave _wave)
    {
        Debug.Log("Wave " + _wave.name + " incoming!");
        state = SpawnState.spawning;

        for(int i = 0; i < _wave.noOfEnemies; i++)
        {
            //Spawn Enemy
            Transform randomPoint = spawnPoints[Random.Range(0, spawnPoints.Length)];
            Instantiate(enemy, randomPoint.position, Quaternion.identity);

            yield return new WaitForSeconds(_wave.spawnInterval);
        }

        state = SpawnState.waitPlayer;

        yield break;
    }

    void WaveCompleted()
    {
        Debug.Log("Wave Completed");

        state = SpawnState.counting;
        waveCountdown = waveInterval;

        if(nextWave + 1 > waves.Length - 1)
        {
            Debug.Log("Finished all waves");
            gameController.GameOver();
        }
        else
        {
            nextWave++;
        }
    } 
}
