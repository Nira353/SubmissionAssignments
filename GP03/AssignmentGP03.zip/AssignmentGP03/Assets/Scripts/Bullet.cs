using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float velocity = 7f;

    private void Update()
    {
        transform.Translate(Vector2.up * velocity * Time.deltaTime);
   
        if (transform.position.y > Camera.main.orthographicSize)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        gameObject.SetActive(false);
    }
}
