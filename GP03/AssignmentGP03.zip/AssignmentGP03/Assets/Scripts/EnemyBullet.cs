using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    public float velocity = 7f;

    private void Update()
    {
        transform.Translate(Vector2.down * velocity * Time.deltaTime);

        if (transform.position.y > Camera.main.orthographicSize)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Player" || collision.gameObject.tag == "Wall")
        {
            gameObject.SetActive(false);
        }
    }
}
