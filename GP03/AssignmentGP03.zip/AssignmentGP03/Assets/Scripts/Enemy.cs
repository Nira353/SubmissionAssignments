using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    GameController gameController;

    public float moveSpeed;
    public float nextShot;

    private void Awake()
    {
        gameController = FindObjectOfType<GameController>();
    }

    void Update()
    {
        transform.Translate(Vector2.down * moveSpeed * Time.deltaTime);
        gameController.bulletEnemyPosition = new Vector3 (transform.position.x, transform.position.y - 1, 0);

        if (nextShot < Time.time)
        {
            gameController.EnemyShoot();
            this.nextShot = this.nextShot + Time.time;
        }

        if (transform.position.y < -Camera.main.orthographicSize)
        {
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.GetComponent<Player>())
        {
            gameController.GameOver();
            Destroy(gameObject);
        }
        if (collision.transform.GetComponent<Bullet>())
        {
            Destroy(gameObject);
        }
    }
}
