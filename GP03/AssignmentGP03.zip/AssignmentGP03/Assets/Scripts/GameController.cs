using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public EnemyWaveController waveController;
    public UIController UIController;

    public bool isPaused = false;

    public Vector3 bulletPlayerPosition;
    public Vector3 bulletEnemyPosition;


    private void Update()
    {
        if (!isPaused && Input.GetKeyDown(KeyCode.P))
        {
            PauseGame();
        }
        else if (isPaused && Input.GetKeyDown(KeyCode.P))
        {
            UnpauseGame();
        }
    }

    public void PlayerShoot()
    {
        GameObject bullet = ObjectPooling.SharedInstance.GetPooledObject(); 
        if (bullet != null) 
        {
            bullet.transform.position = bulletPlayerPosition;
            bullet.transform.rotation = Quaternion.identity;
            bullet.SetActive(true);
        }
    }

    public void EnemyShoot()
    {
        GameObject bulletEnemy = EnemyObjPool.SharedInstanceEB.GetPooledObject();

        if (bulletEnemy != null)
        {
            bulletEnemy.transform.position = bulletEnemyPosition;
            bulletEnemy.transform.rotation = Quaternion.identity;
            bulletEnemy.SetActive(true);
        }
    }

    public void GameOver()
    {
        Time.timeScale = 0;
        UIController.ShowGameOver();
    }

    public void PauseGame()
    {
        isPaused = true;
        Time.timeScale = 0;
        UIController.ShowPausePanel();
    }

    public void UnpauseGame()
    {
        isPaused = false;
        Time.timeScale = 1;
        UIController.HidePausePanel();
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
