using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float moveSpeed = 5.0f;
    public Vector2 movement;

    GameController gameController;

    private void Start()
    {
        gameController = FindObjectOfType<GameController>();

    }

    private void Update()
    {
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");
        transform.Translate(movement * moveSpeed * Time.deltaTime);

        gameController.bulletPlayerPosition = new Vector3(transform.position.x, transform.position.y + 1, 0);

        if (Input.GetKeyDown(KeyCode.Space) && !gameController.isPaused)
        {
            gameController.PlayerShoot();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "EnemyBullet" || collision.gameObject.tag == "Enemy")
        {
            gameController.GameOver();
        }
    }
}
