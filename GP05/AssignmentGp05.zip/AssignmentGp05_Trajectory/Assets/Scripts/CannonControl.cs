using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonControl : MonoBehaviour
{
    [SerializeField] GameManager gameManager;

    void Update()
    {
        float newX = Mathf.Clamp(gameManager.direction.x, 0.2f, 1);
        float newY = Mathf.Clamp(gameManager.direction.y, 0, 1);

        transform.right = new Vector2(newX, newY);
    }
}
