using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Vector3 shootPoint;
    public Ball bullet;

    [HideInInspector] public bool mouseHeld = false;

    Vector2 startPos;
    Vector2 endPos;
    public Vector2 direction;
    public Vector2 force;
    public float distance;

    float minDistance = 3.5f;

    public TrajectoryLine trajectory;
    [SerializeField] float pushForce = 1.5f;

    private void Awake()
    {
        trajectory.Hide();
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            mouseHeld = true;
            OnDragStart();
        }
        if (Input.GetMouseButtonUp(0))
        {
            mouseHeld = false;
            OnDragEnd();
        }

        if (bullet.canShoot) { trajectory.Show(); }

        if (mouseHeld)
        {
            OnDrag();
        }
    }

    void OnDrag()
    {
        endPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        distance = Mathf.Clamp((Vector2.Distance(startPos, endPos) + minDistance), minDistance, 8);
        direction = (startPos - endPos).normalized;

        Debug.Log(distance);

        float newX = Mathf.Clamp(direction.x, 0.2f, 1);
        float newY = Mathf.Clamp(direction.y, 0, 1);

        Vector2 restrictedDirection = new Vector2(newX, newY);
        
        force = restrictedDirection * distance * pushForce;

        trajectory.UpdateDots(trajectory.shootPoint.position, force);
    }

    void OnDragStart()
    {
        startPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }

    void OnDragEnd()
    {
        bullet.ActivateRb();
        bullet.Push(trajectory.shootPoint.position, force);
        trajectory.Hide();
    }
}
