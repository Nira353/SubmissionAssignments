using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    Rigidbody2D rb;
    public bool canShoot = true;


    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        DeactivateRb();
    }

    public void Push(Vector3 pos, Vector2 force)
    {
        transform.position = pos;
        rb.AddForce(force, ForceMode2D.Impulse);
        canShoot = false;
    }

    public void ActivateRb()
    {
        rb.isKinematic = false;
    }

    public void DeactivateRb()
    {
        rb.velocity = Vector3.zero;
        rb.angularVelocity = 0f;
        rb.isKinematic = true;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "ground")
        {
            transform.position = new Vector2(-10,-10);
            canShoot = true;
            DeactivateRb();
        }
    }
}
