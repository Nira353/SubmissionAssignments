using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameEventController : MonoBehaviour
{
    public static GameEventController current;

    private void Awake()
    {
        current = this;
    }

    public event Action<int> OnObjectCollision;
    public void ObjectCollisionEnter(int id)
    {
        if(OnObjectCollision != null)
        {
            OnObjectCollision(id);
        }
    }
}
