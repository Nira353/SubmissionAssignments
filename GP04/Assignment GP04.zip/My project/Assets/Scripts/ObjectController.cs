using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController : MonoBehaviour
{
    public int id;
    void Start()
    {
        GameEventController.current.OnObjectCollision += OnCollisionWithPlayer;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            GameEventController.current.ObjectCollisionEnter(id);
        }
    }

    private void OnCollisionWithPlayer(int _id)
    {
        if(_id == this.id)
        {
            Vector3 currentPos = transform.position;
            transform.position = new Vector3(currentPos.x, currentPos.y + 8, currentPos.z);
        }
    }
}
