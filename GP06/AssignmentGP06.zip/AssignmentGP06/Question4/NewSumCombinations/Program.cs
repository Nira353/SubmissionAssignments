﻿using System;

namespace NewSumCombinations
{
    class Program
    {
        static int count(int n)
        {
            int[] temp = new int[n + 1];
            
            temp[0] = 1;
            for (int i = 1; i <= n ; i++)
            {
                temp[i] = 0;
            }

            for (int t = 3; t <= n; t++)
            {
                temp[t] += temp[t - 3];
            }

            for (int f = 5; f <= n; f++)
            {
                temp[f] += temp[f - 5];
            }
            for (int T = 10; T <= n; T++)
            {
                temp[T] += temp[T - 10];
            }

            return temp[n];
        
        }
        static void Main(string[] args)
        {
            int tests;

            do
            {
                Console.WriteLine("How many test? ");
                tests = Convert.ToInt32(Console.ReadLine());
                if (tests > 100)
                {
                    Console.WriteLine("Invalid test value, please insert again");
                }

            } while (tests > 100);

            int[] scores = new int[tests];

            Console.WriteLine("What numbers: ");
            for (int l = 0; l < tests; l++)
            {
                do
                {
                    scores[l] = Convert.ToInt32(Console.ReadLine());
                    if (scores[l] > 1000)
                    {
                        Console.WriteLine("Invalid score value, please insert again");
                    }

                } while (scores[l] > 1000);
            }

            Console.WriteLine("Results: ");

            for(int l = 0; l < tests; l++)
            {
                Console.WriteLine(count(scores[l]));
            }
        }
    }
}
