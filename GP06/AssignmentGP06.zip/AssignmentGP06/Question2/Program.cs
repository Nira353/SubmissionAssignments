﻿using System;

namespace AssignmentGP06
{
    class PermuteString
    {
        static void permute(String input)
        {
            int n = input.Length;

            int max = (int) Math.Pow(2,n);
                
            input = input.ToLower();

            for (int i = 0; i < max; i++)
            {
                char[] combination = input.ToCharArray();

                for (int j = 0; j < n; j++)
                {
                    if (((i >> j) & 1) == 1)
                        combination[j] = (char)(combination[j] - 32);
                }

                Console.Write(combination);
                Console.Write(" ");
            }
        }

        public static void Main()
        {
            permute("Car");
        }
    }
}
