﻿using System;

namespace Airplane2
{
    public class Program
    {
        public static class Global
        {
            public static int[,] Matrix = new int[,] {  { -1, 1, 0, 0, 1},
                                                        { 1, -1, -1, 1, -1},
                                                        { 0, 0, 1, -1, 1},
                                                        { 0, -1, 0, -1, 0},
                                                        { 1, 1, -1, -1, 1} };

        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var prog = new Program();
            int energy = 1;
            int numberOfCell = 0;
            int[] finalPath = new int[10];


            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine("Partenza dalla colonna numero: " + j);
                prog.SearchPath(finalPath, 4, j, energy, numberOfCell);
            }
        }

        public void SearchPath(int[] path, int line, int column, int fuel, int cellNumber)
        {
            if (line == 0)
            {
                if (column >= 0 && column <= 4)
                {
                    //cellNumber helps me fill int the array that will contain all coordinates, but not in tuple or couples
                    //thats why it is double the lenght of the matrix lines and thats why I print that way in this function
                    path[cellNumber] = line;
                    path[cellNumber + 1] = column;

                    fuel += Global.Matrix[line, column];

                    Console.WriteLine("Possible path: ");

                    for (int i = 0; i < 10;)
                    {
                        Console.WriteLine(path[i] + ", " + path[i + 1] + "\n");
                        i += 2;
                    }
                }
            }

            if (line > 0)
            {
                if (column >= 0 && column <= 4)
                {
                    if (Global.Matrix[line, column] != -1)
                    {
                        path[cellNumber] = line;
                        path[cellNumber + 1] = column;

                        fuel += Global.Matrix[line, column];

                        SearchPath(path, line - 1, column - 1, fuel, cellNumber + 2); //left
                        SearchPath(path, line - 1, column, fuel, cellNumber + 2);     //center
                        SearchPath(path, line - 1, column + 1, fuel, cellNumber + 2); //right
                    }
                }
            }
        }
    }
}
