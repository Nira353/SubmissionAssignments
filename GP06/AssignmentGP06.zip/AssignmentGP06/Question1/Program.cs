﻿using System;

namespace AssignmentGP05
{
    class FibonacciTest
    {
        static void Main(string[] args)
        {
            int counter = 5;
            int n;

            for (int i = 0; i <= counter; i++)
            {
                n = Fibonacci(i);
                Console.WriteLine(n + "\n");
            }
        }
        public static int Fibonacci(int limit)
        {
            if (limit == 0)
            {
                return 0;
            }
            if (limit == 1)
            {
                return 1;
            }

            return Fibonacci((limit - 1)) + Fibonacci((limit - 2));
        }
    }
}